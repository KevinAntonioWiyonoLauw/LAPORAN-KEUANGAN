declare const URIError: URIErrorConstructor;

export = URIError;
