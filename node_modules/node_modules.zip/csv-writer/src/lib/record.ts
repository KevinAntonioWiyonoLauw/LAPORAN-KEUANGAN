
export type Field = any;

export type ObjectHeaderItem = { id: string; title: string };
export type ObjectStringifierHeader = ObjectHeaderItem[] | string[];
